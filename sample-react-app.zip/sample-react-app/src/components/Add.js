import React, { useState } from "react";
import { Button, Form } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { v4 as uuid } from "uuid";
import { Link, useNavigate } from "react-router-dom";
import { Formik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { addData } from "../store/columns-slice";

function Add() {
  const { columns } = useSelector((state) => state.columns);
  const dispatch = useDispatch();
  let history = useNavigate();

  const handleSubmit = (values, { setIsSubmitting }) => {
    dispatch(
      addData({
        id: uuid(),
        ...values,
      })
    );
    history("/");
  };

  return (
    <div className="container">
      <Formik initialValues={{}} onSubmit={handleSubmit}>
        {({ values, handleSubmit, handleChange, handleBlur, isSubmitting }) => (
          <form onSubmit={handleSubmit}>
            {columns.map((column) => {
              return (
                <div className="form-group mt-4">
                  <label>{column.name}</label>
                  <input
                    name={column.name}
                    className="form-control"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values[column.name]}
                  />
                </div>
              );
            })}
            <div className="d-flex justify-content-center mt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn btn-primary"
              >
                Submit
              </button>
            </div>
          </form>
        )}
      </Formik>
    </div>
  );
}

export default Add;
