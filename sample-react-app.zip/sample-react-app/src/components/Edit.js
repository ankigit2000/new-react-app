import "bootstrap/dist/css/bootstrap.min.css";
import { Formik } from "formik";
import React, { useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { updateData } from "../store/columns-slice";

function Edit() {
  const { id } = useParams();
  const { columns, data } = useSelector((state) => state.columns);
  const dispatch = useDispatch();
  let history = useNavigate();

  const initialValues = useMemo(() => {
    return data.find((item) => item.id == id);
  }, [columns, id]);
  const handleSubmit = (values, { setIsSubmitting }) => {
    dispatch(
      updateData({
        id,
        ...values,
      })
    );
    history("/");
  };

  return (
    <div className="container">
      {initialValues ? (
        <Formik initialValues={initialValues} onSubmit={handleSubmit}>
          {({
            values,
            handleSubmit,
            handleChange,
            handleBlur,
            isSubmitting,
          }) => (
            <form onSubmit={handleSubmit}>
              {columns.map((column) => {
                return (
                  <div className="form-group mt-4">
                    <label>{column.name}</label>
                    <input
                      name={column.name}
                      className="form-control"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values[column.name]}
                    />
                  </div>
                );
              })}
              <div className="d-flex justify-content-center mt-4">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn btn-primary"
                >
                  Submit
                </button>
              </div>
            </form>
          )}
        </Formik>
      ) : (
        ""
      )}
    </div>
  );
}

export default Edit;
