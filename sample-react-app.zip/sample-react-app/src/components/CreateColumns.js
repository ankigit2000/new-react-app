import "bootstrap/dist/css/bootstrap.min.css";
import { Formik } from "formik";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addColumn } from "../store/columns-slice";

function CreateColumn() {
  const { columns, data } = useSelector((state) => state.columns);
  const dispatch = useDispatch();
  let history = useNavigate();

  const handleSubmit = (values, { setIsSubmitting }) => {
    dispatch(
      addColumn({
        ...values,
      })
    );
    history("/");
  };

  return (
    <div className="container">
      <Formik initialValues={{}} onSubmit={handleSubmit}>
        {({ values, handleSubmit, handleChange, handleBlur, isSubmitting }) => (
          <form onSubmit={handleSubmit}>
            <div className="form-group mt-4">
              <label>Column Name</label>
              <input
                name={"name"}
                className="form-control"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values["name"]}
              />
            </div>
            <h5 className="mt-3">Values</h5>
            {data.map((item) => {
              return (
                <div key={item.Name} className="form-group mt-4">
                  <label>{item.Name}</label>
                  <input
                    name={item.id}
                    className="form-control"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values[item.id]}
                  />
                </div>
              );
            })}
            <div className="d-flex justify-content-center mt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn btn-primary"
              >
                Submit
              </button>
            </div>
          </form>
        )}
      </Formik>
    </div>
  );
}

export default CreateColumn;
