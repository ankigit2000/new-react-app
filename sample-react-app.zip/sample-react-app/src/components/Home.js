import React, { Fragment } from "react";
import { Button, Table } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { deleteColumn, removeData  } from "../store/columns-slice";
function Home() {
  const { columns, data } = useSelector((state) => state.columns);
  const dispatch = useDispatch();
  const handleDelete = (id) => {
    dispatch(
      removeData({
        id,
      })
    );
  };
 
  // const handleToggleRowExpansion = (id) => {
  //   dispatch(toggleRowExpansion({ id }));
  // };

  const handleRemoveColumn = (name) => {
    dispatch(
      deleteColumn({
        column: name,
      })
    );
  };

  return (
    <Fragment>
      <div style={{ margin: "10rem" }}>
        <div className="my-4 d-flex justify-content-end">
          <Link to={"/create-column"}>
            <button className="btn btn-primary">Add column</button>
          </Link>
        </div>
        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              {columns.map((column) => {
                return (
                  <th key={column.name}>
                    <span>{column.name}</span>
                    {column.dynamic ? (
                      <button onClick={() => handleRemoveColumn(column.name)}>
                        Remove
                      </button>
                    ) : (
                      ""
                    )}
                  </th>
                );
              })}
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data && data.length > 0
              ? data.map((item) => {
                  return (
                    <tr key={item.id}>
                      {columns.map((column) => {
                        return (
                          <td key={item[column.name]}>
                            {item[column.name] || "-"}
                          </td>
                        );
                      })}
                      <td>
                        <Link to={`/edit/${item.id}`}>
                          <Button>Edit</Button>
                        </Link>
                        &nbsp;
                        <Button
                          onClick={() => {
                            handleDelete(item.id);
                          }}
                        >
                          Delete
                        </Button>
                      </td>
                    </tr>
                  );
                })
              : "No data available"}
          </tbody>
        </Table>
        <br />
        <Link className="d-grid gap-2" to="/create">
          <Button size="lg">Create</Button>
        </Link>
      </div>
    </Fragment>
  );
}

export default Home;


