import { configureStore } from "@reduxjs/toolkit";
import columnsSlice from "./columns-slice";
const store = configureStore({
  reducer: {
    columns: columnsSlice,
  },
});
export default store;
