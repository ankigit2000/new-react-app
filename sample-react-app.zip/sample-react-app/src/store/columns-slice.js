import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  columns: [
    {
      name: "Name",
    },
    {
      name: "Skills",
    },
    {
      name: "Designation",
    },
    {
      name: "Age",
    },
  ],
  data: [
    {
      id: "1",
      Name: "Anil",
      Skills: "Angular",
      Designation: "Web Developer",
      Age: 26,
    },
    {
      id: "2",
      Name: "Balaji A M",
      Skills: "DotNet",
      Designation: "Back-End Developer",
      Age: 29,
    },
    {
      id: "3",
      Name: "Vishnu Vijayan",
      Skills: "React",
      Designation: "Web Developer",
      Age: 30,
    },
  ],
};

const columnsSlice = createSlice({
  name: "columns",
  initialState,
  reducers: {
    addColumn: (state, { payload }) => {
      const { name, ...values } = payload;
      state.columns.push({ name, dynamic: true });
      state.data = state.data.map((item) => {
        return {
          ...item,
          [name]: values[item.id],
        };
      });
    },
    deleteColumn: (state, { payload }) => {
      const index = state.columns.findIndex(
        (column) => column.name === payload.column
      );
      state.columns.splice(index, 1);
      state.data = state.data.map((item) => {
        return {
          ...item,
          [payload.column]: "",
        };
      });
    },
    addData: (state, { payload }) => {
      state.data.push(payload);
    },
    removeData: (state, { payload }) => {
      const index = state.data.findIndex((item) => item.id === payload.id);
      if (index !== -1) {
        state.data.splice(index, 1);
      }
    },
    updateData: (state, { payload }) => {
      const index = state.data.findIndex((item) => item.id === payload.id);
      if (index !== -1) {
        state.data.splice(index, 1, payload);
      }
    },
    // toggleRowExpansion: (state, { payload }) => {
    //   const { id } = payload;
    //   const index = state.expandedRows.indexOf(id);
    //   if (index !== -1) {
    //     state.expandedRows.splice(index, 1);
    //   } else {
    //     state.expandedRows.push(id);
    //   }
    // },
  },
});

export const { addColumn, deleteColumn, addData, removeData, updateData } =
  columnsSlice.actions;
export default columnsSlice.reducer;
